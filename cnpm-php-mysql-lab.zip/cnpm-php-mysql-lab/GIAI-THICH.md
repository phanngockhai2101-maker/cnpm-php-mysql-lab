# Giải thích kiến trúc Docker Compose của bài lab

## 1. App container (`app`)
- Chạy image `webdevops/php-apache:8.3`: Apache + PHP 8.3 đã cài sẵn.
- Vai trò: nhận request HTTP từ trình duyệt, chạy code PHP trong thư mục `app/`, gửi truy vấn đến database rồi trả HTML về cho người dùng.
- `WEB_DOCUMENT_ROOT: /app/public` cho Apache biết thư mục gốc của website là `/app/public`, nên chỉ file trong `public/` mới truy cập được từ trình duyệt (thư mục `config/` được giữ kín).

## 2. Database container (`db`)
- Chạy image `mysql:8.0`.
- Vai trò: lưu trữ dữ liệu (bảng `tasks`). App không tự lưu dữ liệu, mọi thao tác thêm/sửa/xóa/đánh dấu hoàn thành đều gửi sang container này.
- Lần đầu khởi tạo, MySQL tự chạy file `database/init.sql` để tạo bảng và dữ liệu mẫu.
- `healthcheck` kiểm tra MySQL đã sẵn sàng chưa; `depends_on` với `condition: service_healthy` bảo đảm container `app` chỉ khởi động sau khi database đã sẵn sàng.
- Hai container nằm chung một mạng do Compose tự tạo, nên `app` kết nối được `db` bằng tên dịch vụ (`DB_HOST: db`) thay vì địa chỉ IP.

## 3. Port mapping (`"${APP_PORT:-8080}:80"`)
- Định dạng `cổng_máy_host:cổng_trong_container`.
- Apache lắng nghe cổng **80 bên trong container**, còn trình duyệt trên máy thật truy cập qua cổng **8080 của máy host** (`http://localhost:8080`). Docker chuyển tiếp lưu lượng từ 8080 vào 80.
- Nếu 8080 đang bị chiếm, chỉ cần đổi `APP_PORT=8081` trong `.env`.
- Container `db` **không** publish cổng ra ngoài, chỉ container `app` trong cùng mạng Compose truy cập được, nên an toàn hơn.

## 4. Environment variables (biến môi trường)
- Dùng để cấu hình container mà không cần sửa code hay image.
- Với `db`: `MYSQL_DATABASE`, `MYSQL_USER`, `MYSQL_PASSWORD`, `MYSQL_ROOT_PASSWORD` quyết định tên database, tài khoản và mật khẩu được tạo.
- Với `app`: `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, `DB_PASSWORD` được code PHP đọc bằng `getenv()` trong `config/database.php` để kết nối database.
- Cú pháp `${MYSQL_USER:-cnpm_user}` nghĩa là lấy giá trị từ file `.env`, nếu không có thì dùng giá trị mặc định `cnpm_user`.
- File `.env` chứa cấu hình riêng của từng máy nên **không commit** lên GitHub (đã nằm trong `.gitignore`); chỉ commit `.env.example` làm mẫu.

## 5. Volume
- Container là tạm thời: xóa container thì dữ liệu bên trong mất. Volume giúp dữ liệu tồn tại độc lập với vòng đời container.
- **Named volume `mysql_data`** (`/var/lib/mysql`): lưu dữ liệu MySQL. Nhờ vậy `docker compose down` rồi `up` lại, dữ liệu vẫn còn. Chỉ `docker compose down -v` mới xóa volume này.
- **Bind mount `./app:/app`**: gắn thư mục `app/` trên máy vào container `app`. Sửa code trên máy là website cập nhật ngay, không cần build lại image.
- **Bind mount `./database/init.sql:/docker-entrypoint-initdb.d/01-init.sql:ro`**: đưa file khởi tạo vào container ở chế độ chỉ đọc (`ro`). File này chỉ chạy khi volume còn trống (lần khởi tạo đầu tiên).
